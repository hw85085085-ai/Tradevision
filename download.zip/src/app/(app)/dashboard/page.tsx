
'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { collection, query, onSnapshot } from 'firebase/firestore';
import { PlusCircle } from 'lucide-react';

import { db } from '@/lib/firebase';
import { type Account, type Trade, type Transaction } from '@/types';
import { Button } from '@/components/ui/button';
import { AddAccountDialog } from '@/components/dashboard/add-account-dialog';
import { AccountCard } from '@/components/dashboard/account-card';
import { Card, CardHeader, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

export default function DashboardPage() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddAccountDialogOpen, setAddAccountDialogOpen] = useState(false);

  useEffect(() => {
    const accountsQuery = query(collection(db, 'accounts'));
    const tradesQuery = query(collection(db, 'trades'));
    const transactionsQuery = query(collection(db, 'transactions'));

    let accountsLoaded = false;
    let tradesLoaded = false;
    let transactionsLoaded = false;

    const checkLoading = () => {
      if (accountsLoaded && tradesLoaded && transactionsLoaded) {
        setIsLoading(false);
      }
    };

    const unsubscribeAccounts = onSnapshot(accountsQuery, (snapshot) => {
      setAccounts(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Account)));
      accountsLoaded = true;
      checkLoading();
    }, (error) => {
      console.error('Error fetching accounts: ', error);
      accountsLoaded = true;
      checkLoading();
    });

    const unsubscribeTrades = onSnapshot(tradesQuery, (snapshot) => {
      setTrades(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Trade)));
      tradesLoaded = true;
      checkLoading();
    }, (error) => {
      console.error('Error fetching trades: ', error);
      tradesLoaded = true;
      checkLoading();
    });

    const unsubscribeTransactions = onSnapshot(transactionsQuery, (snapshot) => {
      setTransactions(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Transaction)));
      transactionsLoaded = true;
      checkLoading();
    }, (error) => {
      console.error('Error fetching transactions: ', error);
      transactionsLoaded = true;
      checkLoading();
    });

    return () => {
      unsubscribeAccounts();
      unsubscribeTrades();
      unsubscribeTransactions();
    };
  }, []);

  const addOptimisticAccount = useCallback((newAccount: Omit<Account, 'id'>) => {
    const optimisticAccount: Account = {
      id: `optimistic-${Date.now()}`,
      ...newAccount,
    };
    setAccounts(currentAccounts => [optimisticAccount, ...currentAccounts]);
  }, []);

  const tradesByAccount = useMemo(() => {
    return trades.reduce((acc, trade) => {
      if (!acc[trade.accountId]) {
        acc[trade.accountId] = [];
      }
      acc[trade.accountId].push(trade);
      return acc;
    }, {} as Record<string, Trade[]>);
  }, [trades]);

  const transactionsByAccount = useMemo(() => {
    return transactions.reduce((acc, transaction) => {
      if (!acc[transaction.accountId]) {
        acc[transaction.accountId] = [];
      }
      acc[transaction.accountId].push(transaction);
      return acc;
    }, {} as Record<string, Transaction[]>);
  }, [transactions]);


  const renderSkeletons = () => (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
      {[...Array(3)].map((_, i) => (
         <Card key={i}>
          <CardHeader>
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-4 w-1/4" />
          </CardHeader>
          <CardContent className="space-y-4">
            {[...Array(7)].map((_, j) => (
               <div key={j} className="flex items-center justify-between">
                <Skeleton className="h-4 w-1/3" />
                <Skeleton className="h-4 w-1/4" />
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Account Dashboard</h1>
          <p className="text-muted-foreground">
            An overview of your trading accounts.
          </p>
        </div>
        <Button onClick={() => setAddAccountDialogOpen(true)}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Account
        </Button>
      </div>

      {isLoading ? (
        renderSkeletons()
      ) : accounts.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {accounts.map((account) => (
            <AccountCard
              key={account.id}
              account={account}
              trades={tradesByAccount[account.id] || []}
              transactions={transactionsByAccount[account.id] || []}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 border-2 border-dashed rounded-lg">
          <h3 className="text-lg font-medium">No accounts yet</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Add a new trading account to get started.
          </p>
          <Button onClick={() => setAddAccountDialogOpen(true)}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Your First Account
          </Button>
        </div>
      )}

      <AddAccountDialog
        open={isAddAccountDialogOpen}
        onOpenChange={setAddAccountDialogOpen}
        onAccountAdded={addOptimisticAccount}
      />
    </div>
  );
}
