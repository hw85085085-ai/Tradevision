
'use client';

import { MainSidebar } from '@/components/main-sidebar';
import { MobileNav } from '@/components/mobile-nav';
import { AuthGuard } from '@/components/auth-guard';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <AuthGuard>
      <div className="flex min-h-screen">
        <MainSidebar />
        <main className="flex-1 bg-background p-4 sm:p-6 lg:p-8 pb-20 md:pb-8">
          {children}
        </main>
        <MobileNav />
      </div>
    </AuthGuard>
  );
}
