
'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { collection, query, onSnapshot, doc, deleteDoc, updateDoc } from 'firebase/firestore';
import { PlusCircle, FileDown } from 'lucide-react';
import {
  startOfWeek,
  endOfWeek,
  subDays,
  startOfMonth,
  endOfMonth,
  isWithinInterval,
  format,
} from 'date-fns';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';


import { db } from '@/lib/firebase';
import { type Trade, type Account } from '@/types';
import { Button } from '@/components/ui/button';
import { AddTradeDialog } from '@/components/journal/add-trade-dialog';
import { EditTradeDialog } from '@/components/journal/edit-trade-dialog';
import { DeleteTradeDialog } from '@/components/journal/delete-trade-dialog';
import { columns } from '@/components/journal/columns';
import { DataTable } from '@/components/journal/data-table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Skeleton } from '@/components/ui/skeleton';
import { AccountProfitChart } from '@/components/journal/account-profit-chart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

type DateRange = 'all' | 'this_week' | 'last_7_days' | 'this_month' | 'last_30_days';

// Extend jsPDF with autoTable - this is a workaround for the type issue
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

export default function JournalPage() {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [filteredAccountId, setFilteredAccountId] = useState<string>('all');
  const [filteredPair, setFilteredPair] = useState<string>('all');
  const [filteredDirection, setFilteredDirection] = useState<'all' | 'Long' | 'Short'>('all');
  const [filteredDateRange, setFilteredDateRange] = useState<DateRange>('all');
  const [isLoading, setIsLoading] = useState(true);
  
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  
  const { toast } = useToast();

  useEffect(() => {
    const tradesQuery = query(collection(db, 'trades'));
    const accountsQuery = query(collection(db, 'accounts'));

    let tradesLoaded = false;
    let accountsLoaded = false;

    const checkLoading = () => {
        if (tradesLoaded && accountsLoaded) {
            setIsLoading(false);
        }
    }

    const unsubscribeTrades = onSnapshot(tradesQuery, (snapshot) => {
      const userTrades: Trade[] = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      } as Trade));
      setTrades(userTrades.sort((a, b) => b.openTime.seconds - a.openTime.seconds));
      tradesLoaded = true;
      checkLoading();
    }, (error) => {
        console.error("Error fetching trades:", error);
        tradesLoaded = true;
        checkLoading();
    });

    const unsubscribeAccounts = onSnapshot(accountsQuery, (snapshot) => {
      const userAccounts: Account[] = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      } as Account));
      setAccounts(userAccounts);
      accountsLoaded = true;
      checkLoading();
    }, (error) => {
        console.error("Error fetching accounts:", error);
        accountsLoaded = true;
        checkLoading();
    });

    return () => {
      unsubscribeTrades();
      unsubscribeAccounts();
    };
  }, []);

  const handleEdit = (trade: Trade) => {
    setSelectedTrade(trade);
    setIsEditDialogOpen(true);
  };

  const handleDelete = (trade: Trade) => {
    setSelectedTrade(trade);
    setIsDeleteDialogOpen(true);
  };
  
  const uniquePairs = useMemo(() => {
    const pairs = new Set(trades.map(trade => trade.pair));
    return ['all', ...Array.from(pairs)];
  }, [trades]);

  const filteredTrades = useMemo(() => {
    let filtered = trades;

    if (filteredAccountId !== 'all') {
      filtered = filtered.filter((trade) => trade.accountId === filteredAccountId);
    }
    if (filteredPair !== 'all') {
      filtered = filtered.filter((trade) => trade.pair === filteredPair);
    }
    if (filteredDirection !== 'all') {
      filtered = filtered.filter((trade) => trade.direction === filteredDirection);
    }
    if (filteredDateRange !== 'all') {
      const now = new Date();
      let interval: Interval;

      switch (filteredDateRange) {
        case 'this_week':
          interval = { start: startOfWeek(now), end: endOfWeek(now) };
          break;
        case 'last_7_days':
          interval = { start: subDays(now, 7), end: now };
          break;
        case 'this_month':
          interval = { start: startOfMonth(now), end: endOfMonth(now) };
          break;
        case 'last_30_days':
          interval = { start: subDays(now, 30), end: now };
          break;
      }
      
      filtered = filtered.filter(trade => {
        const tradeDate = trade.openTime instanceof Date ? trade.openTime : new Date(trade.openTime.seconds * 1000);
        return isWithinInterval(tradeDate, interval);
      })
    }
    
    return filtered;
  }, [trades, filteredAccountId, filteredPair, filteredDirection, filteredDateRange]);
  
  const accountMap = useMemo(() => {
    return new Map(accounts.map(acc => [acc.id, acc.name]));
  }, [accounts]);

  const addOptimisticTrade = useCallback((newTrade: Omit<Trade, 'id' | 'openTime' | 'netProfit' | 'status'> & { openTime: Date }) => {
    const netProfit = newTrade.profit - newTrade.commission;
    const optimisticTrade: Trade = {
      id: `optimistic-${Date.now()}`,
      ...newTrade,
      openTime: newTrade.openTime, // Keep as Date object for sorting
      netProfit: netProfit,
      status: netProfit > 0 ? 'Win' : 'Loss',
    };
    // Add to top of the list
    setTrades(currentTrades => [optimisticTrade, ...currentTrades]);
  }, []);

  const chartData = useMemo(() => {
    if (!filteredTrades.length || !accounts.length) return [];

    const profitByAccount = filteredTrades.reduce((acc, trade) => {
      const accountName = accountMap.get(trade.accountId) || 'Unknown';
      if (!acc[accountName]) {
        acc[accountName] = 0;
      }
      acc[accountName] += trade.netProfit;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(profitByAccount).map(([name, profit]) => ({
      name,
      profit,
    })).sort((a, b) => b.profit - a.profit);
  }, [filteredTrades, accounts, accountMap]);

  const handleExcelExport = () => {
    const dataToExport = filteredTrades.map(trade => ({
        Date: format(new Date(trade.openTime.seconds * 1000), 'PP'),
        Pair: trade.pair,
        Account: accountMap.get(trade.accountId) || 'Unknown',
        Direction: trade.direction,
        'P/L': trade.profit,
        'Net P/L': trade.netProfit,
        Status: trade.status,
        'R:R': trade.rewardRatio,
        Conclusion: trade.conclusion,
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Trades");
    XLSX.writeFile(workbook, "TradeJournal.xlsx");
  };

  const handlePdfExport = () => {
    const doc = new jsPDF();
    const tableColumn = ["Date", "Pair", "Account", "Direction", "Net P/L", "Status", "R:R"];
    const tableRows: (string | number)[][] = [];

    filteredTrades.forEach(trade => {
        const tradeData = [
            format(new Date(trade.openTime.seconds * 1000), 'PP'),
            trade.pair,
            accountMap.get(trade.accountId) || 'Unknown',
            trade.direction,
            trade.netProfit.toFixed(2),
            trade.status,
            trade.rewardRatio || '',
        ];
        tableRows.push(tradeData);
    });

    doc.autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: 20,
    });
    doc.text("Trade Journal", 14, 15);
    doc.save("TradeJournal.pdf");
  };

  const renderTableSkeleton = () => (
    <div className="space-y-4">
      <div className="rounded-md border">
        <div className="flex flex-col space-y-3 p-4">
          <Skeleton className="h-6 w-full" />
          {[...Array(9)].map((_, i) => (
            <Skeleton key={i} className="h-8 w-full" />
          ))}
        </div>
      </div>
    </div>
  );
  
  const noAccounts = accounts.length === 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold">Trade Journal</h1>
          <p className="text-muted-foreground">Log and review all your trades.</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="w-full sm:w-auto">
                    <Button onClick={() => setIsAddDialogOpen(true)} disabled={noAccounts} className="w-full">
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Add Trade
                    </Button>
                  </div>
                </TooltipTrigger>
                {noAccounts && (
                  <TooltipContent>
                    <p>Please add an account first.</p>
                  </TooltipContent>
                )}
              </Tooltip>
            </TooltipProvider>
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="w-full sm:w-auto">
                        <FileDown className="mr-2 h-4 w-4" />
                        Export
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                    <DropdownMenuItem onClick={handleExcelExport}>Export as Excel (.xlsx)</DropdownMenuItem>
                    <DropdownMenuItem onClick={handlePdfExport}>Export as PDF (.pdf)</DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Select value={filteredAccountId} onValueChange={setFilteredAccountId}>
            <SelectTrigger><SelectValue placeholder="Filter by account" /></SelectTrigger>
            <SelectContent>
                <SelectItem value="all">All Accounts</SelectItem>
                {accounts.map(acc => (
                    <SelectItem key={acc.id} value={acc.id}>{acc.name}</SelectItem>
                ))}
            </SelectContent>
        </Select>
         <Select value={filteredPair} onValueChange={setFilteredPair}>
            <SelectTrigger><SelectValue placeholder="Filter by pair" /></SelectTrigger>
            <SelectContent>
              {uniquePairs.map(pair => (
                <SelectItem key={pair} value={pair}>{pair === 'all' ? 'All Pairs' : pair}</SelectItem>
              ))}
            </SelectContent>
        </Select>
        <Select value={filteredDirection} onValueChange={setFilteredDirection}>
            <SelectTrigger><SelectValue placeholder="Filter by direction" /></SelectTrigger>
            <SelectContent>
                <SelectItem value="all">All Directions</SelectItem>
                <SelectItem value="Long">Long</SelectItem>
                <SelectItem value="Short">Short</SelectItem>
            </SelectContent>
        </Select>
        <Select value={filteredDateRange} onValueChange={(value) => setFilteredDateRange(value as DateRange)}>
            <SelectTrigger><SelectValue placeholder="Filter by date" /></SelectTrigger>
            <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="this_week">This Week</SelectItem>
                <SelectItem value="last_7_days">Last 7 Days</SelectItem>
                <SelectItem value="this_month">This Month</SelectItem>
                <SelectItem value="last_30_days">Last 30 Days</SelectItem>
            </SelectContent>
        </Select>
      </div>
      
      {isLoading ? (
        <Skeleton className="h-80 w-full" />
      ) : chartData.length > 0 && filteredTrades.length > 1 ? (
        <Card>
            <CardHeader>
                <CardTitle>Profit by Account</CardTitle>
            </CardHeader>
            <CardContent>
                <AccountProfitChart data={chartData} />
            </CardContent>
        </Card>
      ) : null}

      {isLoading ? (
        renderTableSkeleton()
      ) : (
        <DataTable columns={columns({ accountMap, onEdit: handleEdit, onDelete: handleDelete })} data={filteredTrades} />
      )}

      <AddTradeDialog 
        open={isAddDialogOpen} 
        onOpenChange={setIsAddDialogOpen} 
        accounts={accounts}
        onTradeAdded={addOptimisticTrade} 
      />

      {selectedTrade && (
        <>
            <EditTradeDialog
                open={isEditDialogOpen}
                onOpenChange={setIsEditDialogOpen}
                accounts={accounts}
                trade={selectedTrade}
            />
            <DeleteTradeDialog
                open={isDeleteDialogOpen}
                onOpenChange={setIsDeleteDialogOpen}
                trade={selectedTrade}
            />
        </>
      )}
    </div>
  );
}
